/**
 * Shared code between client and server
 * API client for form system
 */

// API Base URL - defaults to Django backend
// Dynamically determine API base URL based on current hostname
// This allows the app to work when accessed via IP address from other devices
const getApiBaseUrl = () => {
  // Use environment variable if set
  if (import.meta.env.VITE_API_BASE_URL) {
    return import.meta.env.VITE_API_BASE_URL;
  }
  
  // Use current hostname and port 8000 for API
  const hostname = window.location.hostname;
  const protocol = window.location.protocol;
  // If accessing via localhost, use localhost for API
  // Otherwise use the same hostname (IP address)
  const apiUrl = `${protocol}//${hostname}:8000/api`;
  console.log('API Base URL:', apiUrl, '(from hostname:', hostname, ')');
  return apiUrl;
};

const API_BASE_URL = getApiBaseUrl();

// Types
export interface Option {
  value: string;
  text: string;
}

export interface Scale {
  min: number;
  max: number;
  labels?: string[];
}

export interface Visibility {
  dependsOn: string;
  showIfIn: string[];
}

export interface Question {
  id?: string;
  text: string;
  type: 'text' | 'textarea' | 'single_choice' | 'multi_choice' | 'rating' | 'scale';
  options?: Option[];
  required: boolean;
  order: number;
  min_length?: number;
  max_length?: number;
  scale?: Scale;
  visibility?: Visibility;
  exclusive_options?: string[];
}

export interface Section {
  id?: string;
  title: string;
  description?: string;
  order: number;
  questions?: Question[];
  created_at?: string;
}

export interface Form {
  id?: string;
  title: string;
  description?: string;
  status: 'draft' | 'published';
  uuid?: string;
  sections?: Section[];
  welcome_message?: string;
  thank_you_message?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Answer {
  question_id: string;
  value: string | number | string[];
}

export interface Response {
  id?: string;
  form_id: string;
  user_id?: string;
  answers: Answer[];
  submitted_at?: string;
}

export interface ResponseListItem {
  id: string;
  form: string;
  form_title?: string;
  user_id?: string;
  submitted_at: string;
  answer_count: number;
  display_name?: string;
}

export interface ResponseDetail {
  id: string;
  form: string;
  user_id?: string;
  submitted_at: string;
  ip_address?: string;
  answers: Array<{
    question_id: string;
    question_text: string;
    question_type: string;
    value: any;
  }>;
}

// Helper function to get auth token
function getAuthToken(): string | null {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('auth_token');
  }
  return null;
}

// Helper function for API calls
async function apiCall<T>(
  endpoint: string,
  options: RequestInit = {},
  requireAuth: boolean = true
): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`;
  
  // Get auth token if authentication is required
  const token = requireAuth ? getAuthToken() : null;
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };
  
  // Add authorization header if token exists
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  try {
    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      // Handle 401 Unauthorized - token might be expired
      if (response.status === 401 && requireAuth) {
        // Try to refresh token
        const refreshToken = localStorage.getItem('auth_refresh');
        if (refreshToken) {
          try {
            const refreshResponse = await fetch(`${API_BASE_URL}/auth/token/refresh/`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ refresh: refreshToken }),
            });
            
            if (refreshResponse.ok) {
              const refreshData = await refreshResponse.json();
              localStorage.setItem('auth_token', refreshData.access);
              // Retry the original request with new token
              headers['Authorization'] = `Bearer ${refreshData.access}`;
              const retryResponse = await fetch(url, {
                ...options,
                headers,
              });
              
              if (retryResponse.ok) {
                return retryResponse.json();
              }
            }
          } catch (refreshError) {
            // Refresh failed, clear auth and throw error
            localStorage.removeItem('auth_token');
            localStorage.removeItem('auth_refresh');
            localStorage.removeItem('auth_user');
            throw new Error('Session expired. Please login again.');
          }
        }
      }
      
      const error = await response.json().catch(() => ({ detail: response.statusText }));
      const errorMessage = error.detail || error.message || `HTTP error! status: ${response.status}`;
      console.error(`API Error [${response.status}]: ${url}`, errorMessage);
      throw new Error(errorMessage);
    }

    return response.json();
  } catch (error) {
    // Log network errors for debugging
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.error(`Network Error: Failed to fetch ${url}. Make sure the backend is running and accessible.`);
      throw new Error(`خطا در اتصال به سرور. لطفاً مطمئن شوید که سرور در حال اجرا است.`);
    }
    throw error;
  }
}

// Form API functions
export async function createForm(form: Partial<Form>): Promise<Form> {
  return apiCall<Form>('/forms/', {
    method: 'POST',
    body: JSON.stringify(form),
  });
}

export async function getForm(id: string): Promise<Form> {
  return apiCall<Form>(`/forms/${id}/`);
}

export async function listForms(): Promise<Form[]> {
  const response = await apiCall<Form[] | { results: Form[] }>('/forms/');
  // Handle both paginated and non-paginated responses
  if (Array.isArray(response)) {
    return response;
  }
  return response.results || [];
}

export async function updateForm(id: string, form: Partial<Form>): Promise<Form> {
  return apiCall<Form>(`/forms/${id}/`, {
    method: 'PUT',
    body: JSON.stringify(form),
  });
}

export async function deleteForm(id: string): Promise<void> {
  await apiCall(`/forms/${id}/`, {
    method: 'DELETE',
  });
}

export async function publishForm(id: string): Promise<Form> {
  return apiCall<Form>(`/forms/${id}/publish/`, {
    method: 'POST',
  });
}

export async function unpublishForm(id: string): Promise<Form> {
  return apiCall<Form>(`/forms/${id}/unpublish/`, {
    method: 'POST',
  });
}

export async function getPublicForm(uuid: string): Promise<Form> {
  return apiCall<Form>(`/forms/public/${uuid}/`, {}, false);
}

// Response API functions
export async function submitResponse(formId: string, response: Partial<Response>): Promise<Response> {
  return apiCall<Response>(`/responses/submit/${formId}/`, {
    method: 'POST',
    body: JSON.stringify(response),
  }, false);
}

export async function getResponses(formId?: string): Promise<ResponseListItem[]> {
  const endpoint = formId ? `/responses/?form_id=${formId}` : '/responses/';
  const response = await apiCall<ResponseListItem[] | { results: ResponseListItem[] }>(endpoint);
  // Handle both paginated and non-paginated responses
  if (Array.isArray(response)) {
    return response;
  }
  return response.results || [];
}

export async function getResponse(id: string): Promise<ResponseDetail> {
  return apiCall<ResponseDetail>(`/responses/${id}/`);
}

// Analysis types
export interface QuestionAnalysis {
  question_id: number;
  question_text: string;
  question_type: string;
  total_answers: number;
  data: any;
}

export interface FormAnalysis {
  total_responses: number;
  questions: QuestionAnalysis[];
}

// Analysis API function
export async function getFormAnalysis(formId: string): Promise<FormAnalysis> {
  return apiCall<FormAnalysis>(`/forms/${formId}/analysis/`);
}
