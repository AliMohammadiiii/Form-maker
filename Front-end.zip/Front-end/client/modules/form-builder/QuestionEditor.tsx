import { useState } from "react";
import { Question, Option } from "@shared/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { QuestionTypeSelector } from "./QuestionTypeSelector";
import { OptionsEditor } from "./OptionsEditor";
import { VisibilityEditor } from "./VisibilityEditor";
import { GripVertical, Plus, Trash2 } from "lucide-react";

interface QuestionEditorProps {
  questions: Question[];
  onChange: (questions: Question[]) => void;
}

export function QuestionEditor({ questions, onChange }: QuestionEditorProps) {
  const [expandedQuestion, setExpandedQuestion] = useState<number | null>(null);

  const addQuestion = () => {
    const newQuestion: Question = {
      text: "",
      type: "text",
      required: false,
      order: questions.length,
      options: [],
    };
    onChange([...questions, newQuestion]);
    setExpandedQuestion(questions.length);
  };

  const updateQuestion = (index: number, updates: Partial<Question>) => {
    const updated = [...questions];
    updated[index] = { ...updated[index], ...updates };
    onChange(updated);
  };

  const deleteQuestion = (index: number) => {
    const updated = questions.filter((_, i) => i !== index);
    updated.forEach((q, i) => {
      q.order = i;
    });
    onChange(updated);
    if (expandedQuestion === index) {
      setExpandedQuestion(null);
    }
  };

  const moveQuestion = (index: number, direction: "up" | "down") => {
    if (
      (direction === "up" && index === 0) ||
      (direction === "down" && index === questions.length - 1)
    ) {
      return;
    }
    const updated = [...questions];
    const newIndex = direction === "up" ? index - 1 : index + 1;
    [updated[index], updated[newIndex]] = [updated[newIndex], updated[index]];
    updated[index].order = index;
    updated[newIndex].order = newIndex;
    onChange(updated);
    setExpandedQuestion(newIndex);
  };

  return (
    <div className="space-y-3 mt-4">
      <div className="flex items-center justify-between mb-2">
        <Label>سوالات</Label>
      </div>
      {questions.map((question, index) => (
        <Card key={index} className="relative">
          <CardContent className="p-4">
            <div
              className="flex items-center justify-between cursor-pointer mb-2"
              onClick={() =>
                setExpandedQuestion(expandedQuestion === index ? null : index)
              }
            >
              <div className="flex items-center gap-2 flex-1">
                <GripVertical className="w-4 h-4 text-text-tertiary" />
                <span className="text-sm font-medium">
                  {question.text || `سوال ${index + 1}`}
                </span>
                {question.required && (
                  <span className="text-xs text-destructive">*</span>
                )}
              </div>
              <div className="flex items-center gap-1">
                {index > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      moveQuestion(index, "up");
                    }}
                  >
                    ↑
                  </Button>
                )}
                {index < questions.length - 1 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      moveQuestion(index, "down");
                    }}
                  >
                    ↓
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteQuestion(index);
                  }}
                  className="text-destructive"
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>

            {expandedQuestion === index && (
              <div className="space-y-4 mt-4 pt-4 border-t">
                <div>
                  <Label>متن سوال</Label>
                  <Input
                    value={question.text}
                    onChange={(e) =>
                      updateQuestion(index, { text: e.target.value })
                    }
                    placeholder="متن سوال را وارد کنید"
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>نوع سوال</Label>
                  <QuestionTypeSelector
                    value={question.type}
                    onChange={(type) => {
                      const updates: Partial<Question> = { type };
                      // Reset type-specific fields
                      if (!["single_choice", "multi_choice"].includes(type)) {
                        updates.options = [];
                      }
                      if (!["rating", "scale"].includes(type)) {
                        updates.scale = undefined;
                      }
                      updateQuestion(index, updates);
                    }}
                  />
                </div>

                <div className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox
                    id={`required-${index}`}
                    checked={question.required}
                    onCheckedChange={(checked) =>
                      updateQuestion(index, { required: !!checked })
                    }
                  />
                  <Label htmlFor={`required-${index}`} className="cursor-pointer">
                    سوال اجباری
                  </Label>
                </div>

                {(question.type === "single_choice" ||
                  question.type === "multi_choice") && (
                  <OptionsEditor
                    options={question.options || []}
                    exclusiveOptions={question.exclusive_options || []}
                    onChange={(options, exclusiveOptions) =>
                      updateQuestion(index, {
                        options,
                        exclusive_options: exclusiveOptions,
                      })
                    }
                  />
                )}

                {(question.type === "rating" || question.type === "scale") && (
                  <div className="space-y-2">
                    <Label>مقیاس</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label className="text-xs">حداقل</Label>
                        <Input
                          type="number"
                          value={question.scale?.min || 1}
                          onChange={(e) =>
                            updateQuestion(index, {
                              scale: {
                                ...question.scale,
                                min: parseInt(e.target.value) || 1,
                                max: question.scale?.max || 5,
                                labels: question.scale?.labels || [],
                              },
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label className="text-xs">حداکثر</Label>
                        <Input
                          type="number"
                          value={question.scale?.max || 5}
                          onChange={(e) =>
                            updateQuestion(index, {
                              scale: {
                                ...question.scale,
                                min: question.scale?.min || 1,
                                max: parseInt(e.target.value) || 5,
                                labels: question.scale?.labels || [],
                              },
                            })
                          }
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs">برچسب‌ها (اختیاری، با کاما جدا کنید)</Label>
                      <Input
                        value={question.scale?.labels?.join(", ") || ""}
                        onChange={(e) => {
                          const labels = e.target.value
                            .split(",")
                            .map((l) => l.trim())
                            .filter(Boolean);
                          updateQuestion(index, {
                            scale: {
                              ...question.scale,
                              min: question.scale?.min || 1,
                              max: question.scale?.max || 5,
                              labels,
                            },
                          });
                        }}
                        placeholder="برچسب 1, برچسب 2, ..."
                      />
                    </div>
                  </div>
                )}

                {(question.type === "text" || question.type === "textarea") && (
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">حداقل طول</Label>
                      <Input
                        type="number"
                        value={question.min_length || ""}
                        onChange={(e) =>
                          updateQuestion(index, {
                            min_length: e.target.value
                              ? parseInt(e.target.value)
                              : undefined,
                          })
                        }
                        placeholder="اختیاری"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">حداکثر طول</Label>
                      <Input
                        type="number"
                        value={question.max_length || ""}
                        onChange={(e) =>
                          updateQuestion(index, {
                            max_length: e.target.value
                              ? parseInt(e.target.value)
                              : undefined,
                          })
                        }
                        placeholder="اختیاری"
                      />
                    </div>
                  </div>
                )}

                <VisibilityEditor
                  visibility={question.visibility}
                  questions={questions}
                  currentIndex={index}
                  onChange={(visibility) =>
                    updateQuestion(index, { visibility })
                  }
                />
              </div>
            )}
          </CardContent>
        </Card>
      ))}

      <Button
        onClick={addQuestion}
        variant="outline"
        size="sm"
        className="w-full border-dashed"
      >
        <Plus className="w-3 h-3 ml-2" />
        افزودن سوال
      </Button>
    </div>
  );
}

