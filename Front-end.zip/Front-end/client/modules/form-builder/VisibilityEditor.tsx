import { useState } from "react";
import { Question, Visibility } from "@shared/api";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface VisibilityEditorProps {
  visibility?: Visibility;
  questions: Question[];
  currentIndex: number;
  onChange: (visibility: Visibility | undefined) => void;
}

export function VisibilityEditor({
  visibility,
  questions,
  currentIndex,
  onChange,
}: VisibilityEditorProps) {
  const [enabled, setEnabled] = useState(!!visibility);

  const availableQuestions = questions.filter(
    (_, index) => index < currentIndex
  );

  if (availableQuestions.length === 0) {
    return null;
  }

  return (
    <div className="space-y-2 p-3 border rounded-lg bg-muted/50">
      <div className="flex items-center space-x-2 space-x-reverse">
        <Checkbox
          checked={enabled}
          onCheckedChange={(checked) => {
            setEnabled(!!checked);
            if (!checked) {
              onChange(undefined);
            } else {
              onChange({
                dependsOn: availableQuestions[0].text || "",
                showIfIn: [],
              });
            }
          }}
        />
        <Label className="cursor-pointer">نمایش شرطی</Label>
      </div>

      {enabled && (
        <div className="space-y-2 mt-2">
          <div>
            <Label className="text-xs">وابسته به سوال</Label>
            <Select
              value={visibility?.dependsOn || ""}
              onValueChange={(value) =>
                onChange({
                  dependsOn: value,
                  showIfIn: visibility?.showIfIn || [],
                })
              }
            >
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="انتخاب سوال" />
              </SelectTrigger>
              <SelectContent>
                {availableQuestions.map((q, index) => (
                  <SelectItem key={index} value={q.text}>
                    {q.text || `سوال ${index + 1}`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {visibility?.dependsOn && (
            <div>
              <Label className="text-xs">
                نمایش زمانی که پاسخ یکی از این مقادیر باشد (با کاما جدا کنید)
              </Label>
              <Input
                value={visibility.showIfIn?.join(", ") || ""}
                onChange={(e) => {
                  const values = e.target.value
                    .split(",")
                    .map((v) => v.trim())
                    .filter(Boolean);
                  onChange({
                    dependsOn: visibility.dependsOn,
                    showIfIn: values,
                  });
                }}
                placeholder="مقدار 1, مقدار 2, ..."
                className="mt-1"
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

