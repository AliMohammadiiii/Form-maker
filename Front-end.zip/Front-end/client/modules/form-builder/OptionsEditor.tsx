import { useState } from "react";
import { Option } from "@shared/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Trash2 } from "lucide-react";

interface OptionsEditorProps {
  options: Option[];
  exclusiveOptions: string[];
  onChange: (options: Option[], exclusiveOptions: string[]) => void;
}

export function OptionsEditor({
  options,
  exclusiveOptions,
  onChange,
}: OptionsEditorProps) {
  const addOption = () => {
    const newOption: Option = {
      value: `option_${Date.now()}`,
      text: "",
    };
    onChange([...options, newOption], exclusiveOptions);
  };

  const updateOption = (index: number, updates: Partial<Option>) => {
    const updated = [...options];
    updated[index] = { ...updated[index], ...updates };
    onChange(updated, exclusiveOptions);
  };

  const deleteOption = (index: number) => {
    const updated = options.filter((_, i) => i !== index);
    const removedValue = options[index].value;
    const updatedExclusive = exclusiveOptions.filter((v) => v !== removedValue);
    onChange(updated, updatedExclusive);
  };

  const toggleExclusive = (value: string, checked: boolean) => {
    if (checked) {
      onChange(options, [...exclusiveOptions, value]);
    } else {
      onChange(
        options,
        exclusiveOptions.filter((v) => v !== value)
      );
    }
  };

  return (
    <div className="space-y-2">
      <Label>گزینه‌ها</Label>
      {options.map((option, index) => (
        <div key={index} className="flex items-center gap-2">
          <Input
            value={option.value}
            onChange={(e) =>
              updateOption(index, { value: e.target.value })
            }
            placeholder="مقدار"
            className="flex-1"
          />
          <Input
            value={option.text}
            onChange={(e) =>
              updateOption(index, { text: e.target.value })
            }
            placeholder="متن نمایشی"
            className="flex-1"
          />
          <div className="flex items-center gap-1">
            <Checkbox
              checked={exclusiveOptions.includes(option.value)}
              onCheckedChange={(checked) =>
                toggleExclusive(option.value, !!checked)
              }
            />
            <Label className="text-xs">انحصاری</Label>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => deleteOption(index)}
            className="text-destructive"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      ))}
      <Button
        onClick={addOption}
        variant="outline"
        size="sm"
        className="w-full border-dashed"
      >
        <Plus className="w-3 h-3 ml-2" />
        افزودن گزینه
      </Button>
    </div>
  );
}

