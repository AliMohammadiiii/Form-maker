import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Form, Section, Question } from "@shared/api";
import { createForm, getForm, updateForm, publishForm } from "@shared/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SectionEditor } from "./SectionEditor";
import { FormPreview } from "./FormPreview";
import { toast } from "@/hooks/use-toast";

export function FormBuilder() {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const isEditing = !!id;

  const [formData, setFormData] = useState<Partial<Form>>({
    title: "",
    description: "",
    status: "draft",
    sections: [],
    welcome_message: "",
    thank_you_message: "",
  });

  const { data: existingForm, isLoading } = useQuery({
    queryKey: ["form", id],
    queryFn: () => getForm(String(id!)),
    enabled: isEditing,
  });

  useEffect(() => {
    if (existingForm) {
      setFormData(existingForm);
    }
  }, [existingForm]);

  // Update page title
  useEffect(() => {
    if (isEditing && formData.title) {
      document.title = `ویرایش فرم - ${formData.title}`;
    } else if (isEditing) {
      document.title = "ویرایش فرم";
    } else {
      document.title = "ایجاد فرم جدید";
    }
    
    // Cleanup: reset title when component unmounts
    return () => {
      document.title = "سیستم فرم‌ساز";
    };
  }, [isEditing, formData.title]);

  const createMutation = useMutation({
    mutationFn: createForm,
    onSuccess: (data) => {
      toast({
        title: "Form created successfully",
        description: "Your form has been saved.",
      });
      navigate(`/builder/${data.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, form }: { id: string; form: Partial<Form> }) =>
      updateForm(id, form),
    onSuccess: () => {
      toast({
        title: "Form updated successfully",
        description: "Your changes have been saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["form", id] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const publishMutation = useMutation({
    mutationFn: publishForm,
    onSuccess: () => {
      toast({
        title: "Form published",
        description: "Your form is now live!",
      });
      queryClient.invalidateQueries({ queryKey: ["form", id] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const cleanFormData = (data: Partial<Form>): Partial<Form> => {
    // Filter out questions with empty text
    const cleanedSections = data.sections?.map((section) => ({
      ...section,
      questions: section.questions?.filter(
        (q) => q.text && q.text.trim().length > 0
      ),
    })).filter((section) => {
      // Filter out sections with no questions
      return section.questions && section.questions.length > 0;
    });
    
    return {
      ...data,
      sections: cleanedSections,
    };
  };

  const handleSave = () => {
    const cleanedData = cleanFormData(formData);
    if (isEditing && id) {
      updateMutation.mutate({ id: String(id), form: cleanedData });
    } else {
      createMutation.mutate(cleanedData);
    }
  };

  const handlePublish = () => {
    if (id) {
      publishMutation.mutate(String(id));
    }
  };

  const handleSectionsChange = (sections: Section[]) => {
    setFormData({ ...formData, sections });
  };

  if (isLoading) {
    return <div className="p-8">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-bg-secondary p-4" dir="rtl">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-text-primary">
            {isEditing ? "ویرایش فرم" : "ایجاد فرم جدید"}
          </h1>
          <div className="flex gap-2">
            <Button onClick={handleSave} variant="outline">
              ذخیره
            </Button>
            {isEditing && formData.status === "draft" && (
              <Button onClick={handlePublish} className="bg-primary">
                انتشار
              </Button>
            )}
          </div>
        </div>

        <Card className="mb-4">
          <CardHeader>
            <CardTitle>اطلاعات فرم</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="title">عنوان فرم</Label>
              <Input
                id="title"
                value={formData.title || ""}
                onChange={(e) =>
                  setFormData({ ...formData, title: e.target.value })
                }
                placeholder="عنوان فرم را وارد کنید"
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="description">توضیحات</Label>
              <Textarea
                id="description"
                value={formData.description || ""}
                onChange={(e) =>
                  setFormData({ ...formData, description: e.target.value })
                }
                placeholder="توضیحات فرم"
                className="mt-2"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="mb-4">
          <CardHeader>
            <CardTitle>پیام خوش‌آمدگویی</CardTitle>
          </CardHeader>
          <CardContent>
            <div>
              <Label htmlFor="welcome_message">پیام نمایش داده شده در ابتدای فرم</Label>
              <Textarea
                id="welcome_message"
                value={formData.welcome_message || ""}
                onChange={(e) =>
                  setFormData({ ...formData, welcome_message: e.target.value })
                }
                placeholder="پیام خوش‌آمدگویی. این پیام در ابتدای فرم نمایش داده می‌شود."
                className="mt-2"
                rows={4}
              />
              <p className="text-sm text-text-secondary mt-2">
                اگر این فیلد خالی باشد، پیام پیش‌فرض نمایش داده می‌شود.
              </p>
              <p className="text-sm text-text-secondary mt-1">
                برای بولد کردن متن، از **متن** استفاده کنید. مثال: **خوش اومدی!**
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-4">
          <CardHeader>
            <CardTitle>پیام تشکر</CardTitle>
          </CardHeader>
          <CardContent>
            <div>
              <Label htmlFor="thank_you_message">پیام نمایش داده شده پس از ارسال فرم</Label>
              <Textarea
                id="thank_you_message"
                value={formData.thank_you_message || ""}
                onChange={(e) =>
                  setFormData({ ...formData, thank_you_message: e.target.value })
                }
                placeholder="پیام تشکر. این پیام پس از ارسال موفق فرم نمایش داده می‌شود."
                className="mt-2"
                rows={4}
              />
              <p className="text-sm text-text-secondary mt-2">
                اگر این فیلد خالی باشد، پیام پیش‌فرض نمایش داده می‌شود.
              </p>
              <p className="text-sm text-text-secondary mt-1">
                برای بولد کردن متن، از **متن** استفاده کنید. مثال: **ممنون از شما!**
              </p>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="builder" className="w-full">
          <TabsList>
            <TabsTrigger value="builder">سازنده</TabsTrigger>
            <TabsTrigger value="preview">پیش‌نمایش</TabsTrigger>
          </TabsList>
          <TabsContent value="builder">
            <SectionEditor
              sections={formData.sections || []}
              onChange={handleSectionsChange}
            />
          </TabsContent>
          <TabsContent value="preview">
            <FormPreview form={formData as Form} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

