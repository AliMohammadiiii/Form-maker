import { Form } from "@shared/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { QuestionRenderer } from "../form-view/QuestionRenderer";

interface FormPreviewProps {
  form: Form;
}

export function FormPreview({ form }: FormPreviewProps) {
  if (!form.sections || form.sections.length === 0) {
    return (
      <div className="p-8 text-center text-text-secondary">
        هیچ بخشی اضافه نشده است. بخش‌ها و سوالات را در تب "سازنده" اضافه کنید.
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-text-primary mb-2">
          {form.title || "فرم بدون عنوان"}
        </h2>
        {form.description && (
          <p className="text-text-secondary">{form.description}</p>
        )}
      </div>

      {(form.welcome_message || form.thank_you_message) && (
        <div className="space-y-4 mb-6">
          {form.welcome_message && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">پیام خوش‌آمدگویی</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-text-secondary whitespace-pre-line">
                  {form.welcome_message}
                </div>
              </CardContent>
            </Card>
          )}
          {form.thank_you_message && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">پیام تشکر</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-text-secondary whitespace-pre-line">
                  {form.thank_you_message}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {form.sections.map((section, sectionIndex) => (
        <Card key={sectionIndex}>
          <CardHeader>
            <CardTitle>{section.title || `بخش ${sectionIndex + 1}`}</CardTitle>
            {section.description && (
              <p className="text-sm text-text-secondary mt-2">
                {section.description}
              </p>
            )}
          </CardHeader>
          <CardContent className="space-y-4">
            {section.questions && section.questions.length > 0 ? (
              section.questions.map((question, questionIndex) => (
                <div key={questionIndex} className="space-y-2">
                  <label className="text-sm font-medium text-text-secondary">
                    {question.text}
                    {question.required && (
                      <span className="text-destructive mr-1">*</span>
                    )}
                  </label>
                  <QuestionRenderer
                    question={question}
                    value={undefined}
                    onChange={() => {}}
                    disabled={true}
                  />
                </div>
              ))
            ) : (
              <p className="text-sm text-text-tertiary">
                هیچ سوالی در این بخش وجود ندارد
              </p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

