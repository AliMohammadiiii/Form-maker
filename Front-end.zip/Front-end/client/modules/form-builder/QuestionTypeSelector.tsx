import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Question } from "@shared/api";

interface QuestionTypeSelectorProps {
  value: Question["type"];
  onChange: (type: Question["type"]) => void;
}

export function QuestionTypeSelector({
  value,
  onChange,
}: QuestionTypeSelectorProps) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="mt-2">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="text">متن کوتاه</SelectItem>
        <SelectItem value="textarea">متن بلند</SelectItem>
        <SelectItem value="single_choice">انتخاب تکی</SelectItem>
        <SelectItem value="multi_choice">انتخاب چندگانه</SelectItem>
        <SelectItem value="rating">امتیازدهی</SelectItem>
        <SelectItem value="scale">مقیاس</SelectItem>
      </SelectContent>
    </Select>
  );
}

