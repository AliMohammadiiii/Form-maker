import { useState } from "react";
import { Section, Question } from "@shared/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { QuestionEditor } from "./QuestionEditor";
import { GripVertical, Plus, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface SectionEditorProps {
  sections: Section[];
  onChange: (sections: Section[]) => void;
}

export function SectionEditor({ sections, onChange }: SectionEditorProps) {
  const [expandedSection, setExpandedSection] = useState<number | null>(0);

  const addSection = () => {
    const newSection: Section = {
      title: `بخش ${sections.length + 1}`,
      description: "",
      order: sections.length,
      questions: [],
    };
    onChange([...sections, newSection]);
    setExpandedSection(sections.length);
  };

  const updateSection = (index: number, updates: Partial<Section>) => {
    const updated = [...sections];
    updated[index] = { ...updated[index], ...updates };
    onChange(updated);
  };

  const deleteSection = (index: number) => {
    const updated = sections.filter((_, i) => i !== index);
    // Reorder sections
    updated.forEach((section, i) => {
      section.order = i;
    });
    onChange(updated);
    if (expandedSection === index) {
      setExpandedSection(null);
    }
  };

  const moveSection = (index: number, direction: "up" | "down") => {
    if (
      (direction === "up" && index === 0) ||
      (direction === "down" && index === sections.length - 1)
    ) {
      return;
    }
    const updated = [...sections];
    const newIndex = direction === "up" ? index - 1 : index + 1;
    [updated[index], updated[newIndex]] = [updated[newIndex], updated[index]];
    updated[index].order = index;
    updated[newIndex].order = newIndex;
    onChange(updated);
    setExpandedSection(newIndex);
  };

  const handleQuestionsChange = (index: number, questions: Question[]) => {
    updateSection(index, { questions });
  };

  return (
    <div className="space-y-4">
      {sections.map((section, index) => (
        <Card key={index} className="relative">
          <CardHeader
            className="cursor-pointer"
            onClick={() =>
              setExpandedSection(expandedSection === index ? null : index)
            }
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 flex-1">
                <GripVertical className="w-5 h-5 text-text-tertiary" />
                <CardTitle className="text-lg">
                  {section.title || `بخش ${index + 1}`}
                </CardTitle>
              </div>
              <div className="flex items-center gap-2">
                {index > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      moveSection(index, "up");
                    }}
                  >
                    ↑
                  </Button>
                )}
                {index < sections.length - 1 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      moveSection(index, "down");
                    }}
                  >
                    ↓
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteSection(index);
                  }}
                  className="text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          {expandedSection === index && (
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor={`section-title-${index}`}>عنوان بخش</Label>
                <Input
                  id={`section-title-${index}`}
                  value={section.title}
                  onChange={(e) =>
                    updateSection(index, { title: e.target.value })
                  }
                  placeholder="عنوان بخش"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor={`section-desc-${index}`}>توضیحات</Label>
                <Textarea
                  id={`section-desc-${index}`}
                  value={section.description || ""}
                  onChange={(e) =>
                    updateSection(index, { description: e.target.value })
                  }
                  placeholder="توضیحات بخش"
                  className="mt-2"
                  rows={2}
                />
              </div>
              <QuestionEditor
                questions={section.questions || []}
                onChange={(questions) => handleQuestionsChange(index, questions)}
              />
            </CardContent>
          )}
        </Card>
      ))}

      <Button
        onClick={addSection}
        variant="outline"
        className="w-full border-dashed"
      >
        <Plus className="w-4 h-4 ml-2" />
        افزودن بخش جدید
      </Button>
    </div>
  );
}

