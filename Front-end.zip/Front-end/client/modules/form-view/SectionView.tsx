import { Section, Question } from "@shared/api";
import { QuestionRenderer } from "./QuestionRenderer";

interface SectionViewProps {
  section: Section;
  answers: Record<number, any>;
  visibleQuestions: Question[];
  onAnswerChange: (questionId: number, value: any) => void;
}

export function SectionView({
  section,
  answers,
  visibleQuestions,
  onAnswerChange,
}: SectionViewProps) {
  const visibleSectionQuestions =
    section.questions?.filter((q) =>
      visibleQuestions.some((vq) => vq.id === q.id)
    ) || [];

  return (
    <div className="flex flex-col items-start gap-6 w-full overflow-y-auto">
      <div className="text-sm font-bold text-text-secondary leading-6 text-right w-full">
        {section.title}
      </div>
      {section.description && (
        <div className="text-sm text-text-tertiary text-right w-full">
          {section.description}
        </div>
      )}

      <div className="flex flex-col items-start gap-4 w-full">
        {visibleSectionQuestions.map((question) => (
          <div key={question.id} className="w-full space-y-2">
            <label className="text-sm font-bold text-text-secondary leading-6 text-right block">
              {question.text}
              {question.required && (
                <span className="text-destructive mr-1">*</span>
              )}
            </label>
            <QuestionRenderer
              question={question}
              value={answers[question.id!]}
              onChange={(value) => onAnswerChange(question.id!, value)}
              disabled={false}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

