import { Scale } from "@shared/api";
import { cn } from "@/lib/utils";

interface RatingInputProps {
  scale?: Scale;
  value?: number;
  onChange: (value: number) => void;
  disabled?: boolean;
}

export function RatingInput({
  scale,
  value,
  onChange,
  disabled = false,
}: RatingInputProps) {
  const min = scale?.min || 1;
  const max = scale?.max || 5;
  const labels = scale?.labels || [];
  const range = Array.from({ length: max - min + 1 }, (_, i) => min + i);

  return (
    <div className="flex flex-col gap-3 w-full">
      <div className="flex items-center justify-center gap-2">
        {range.map((num) => (
          <button
            key={num}
            type="button"
            onClick={() => !disabled && onChange(num)}
            disabled={disabled}
            className={cn(
              "w-12 h-12 rounded-full border-2 font-bold text-sm transition-all",
              value === num
                ? "bg-primary border-primary text-white"
                : "bg-white border-stroke-tertiary text-text-secondary hover:border-primary",
              disabled && "cursor-not-allowed opacity-50"
            )}
          >
            {num}
          </button>
        ))}
      </div>
      {labels.length > 0 && value && (
        <div className="text-center text-sm text-text-secondary">
          {labels[value - min] || ""}
        </div>
      )}
    </div>
  );
}

