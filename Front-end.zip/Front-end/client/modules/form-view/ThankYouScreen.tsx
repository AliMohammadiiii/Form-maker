import { Form } from "@shared/api";
import { Button } from "@/components/ui/button";
import { parseBoldText } from "@/lib/utils";

interface ThankYouScreenProps {
  form?: Form;
}

export function ThankYouScreen({ form }: ThankYouScreenProps) {
  const defaultThankYouMessage = `**ممنون از شما!** 👋

ممنون که به سوالات پاسخ دادی.`;

  const thankYouText = form?.thank_you_message || defaultThankYouMessage;

  return (
    <div className="min-h-screen bg-bg-secondary flex flex-col items-center" dir="rtl">
      <div className="w-full max-w-md">
        <div className="flex w-full h-14 items-center justify-center pt-4 pb-5">
          <h1 className="text-text-primary text-center font-bold text-base leading-5.5">
            پرسشنامه{form?.title ? ` - ${form.title}` : ''}
          </h1>
        </div>

        <div className="flex w-full px-4 flex-col items-end gap-4 pb-20">
          <div 
            className="flex w-full flex-col items-end gap-4 rounded-xl bg-white h-[calc(100vh-168px)] overflow-hidden"
            style={{
              padding: '16px',
            }}
          >
            <div className="flex w-full justify-center items-center h-full">
              <div 
                className="flex flex-col items-end justify-center gap-[15px] w-full max-w-[324px]"
              >
                <div className="w-full text-right" style={{ color: '#4F545E' }}>
                  {thankYouText.split('\n\n').map((paragraph, pIndex) => {
                    if (pIndex === 0) {
                      // First paragraph - check for emoji and handle bold text
                      const emojiIndex = paragraph.indexOf('👋');
                      if (emojiIndex !== -1) {
                        const beforeEmoji = paragraph.substring(0, emojiIndex).trim();
                        const afterEmoji = paragraph.substring(emojiIndex);
                        return (
                          <div key={pIndex} className="mb-[15px]" style={{
                            fontFamily: 'IRANYekanXFaNum',
                            fontSize: '18px',
                            fontWeight: 400,
                            lineHeight: '24px',
                            color: '#4F545E',
                            textAlign: 'right'
                          }}>
                            <span>{parseBoldText(beforeEmoji)}</span>
                            <span> {afterEmoji}</span>
                          </div>
                        );
                      } else {
                        // No emoji, parse bold text in first line
                        return (
                          <div key={pIndex} className="mb-[15px]" style={{
                            fontFamily: 'IRANYekanXFaNum',
                            fontSize: '18px',
                            fontWeight: 400,
                            lineHeight: '24px',
                            color: '#4F545E',
                            textAlign: 'right'
                          }}>
                            {parseBoldText(paragraph)}
                          </div>
                        );
                      }
                    }
                    return (
                      <div 
                        key={pIndex} 
                        className={pIndex > 0 ? 'mt-[15px]' : ''}
                        style={{
                          fontFamily: 'IRANYekanXFaNum',
                          fontSize: '14px',
                          fontWeight: 400,
                          lineHeight: '24px',
                          color: '#4F545E',
                          textAlign: 'right'
                        }}
                      >
                        {parseBoldText(paragraph)}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="fixed bottom-0 left-0 right-0 flex w-full max-w-md mx-auto px-4 py-3 pb-5 flex-col items-start gap-2.5 bg-bg-secondary">
          <Button
            onClick={() => window.location.href = '/'}
            className="flex w-full h-12 px-0 py-3.5 justify-center items-center gap-1 rounded-xl bg-primary text-white font-bold text-sm leading-5 hover:bg-primary/90 transition-colors"
          >
            تأیید
          </Button>
        </div>
      </div>
    </div>
  );
}
