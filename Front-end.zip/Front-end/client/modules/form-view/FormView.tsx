import { useState, useEffect, useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Form, Question, Answer } from "@shared/api";
import { getPublicForm, submitResponse } from "@shared/api";
import { ProgressStepper } from "@/components/form/ProgressStepper";
import { RadioButton } from "@/components/form/RadioButton";
import { Checkbox } from "@/components/form/Checkbox";
import { TextArea } from "@/components/form/TextArea";
import { RatingInput } from "./RatingInput";
import { ThankYouScreen } from "./ThankYouScreen";
import { WelcomeScreen } from "./WelcomeScreen";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export function FormView() {
  const { uuid } = useParams<{ uuid: string }>();
  const navigate = useNavigate();
  const [showWelcome, setShowWelcome] = useState(true);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [submitted, setSubmitted] = useState(false);

  const { data: form, isLoading, error } = useQuery<Form>({
    queryKey: ["public-form", uuid],
    queryFn: () => getPublicForm(uuid!),
    enabled: !!uuid,
    retry: 2,
  });

  // Update page title when form is loaded
  useEffect(() => {
    if (form?.title) {
      document.title = form.title;
    } else {
      document.title = "پرسشنامه";
    }
    
    // Cleanup: reset title when component unmounts
    return () => {
      document.title = "سیستم فرم‌ساز";
    };
  }, [form?.title]);

  const submitMutation = useMutation({
    mutationFn: (data: { formId: string; answers: Answer[] }) =>
      submitResponse(data.formId, { answers: data.answers }),
    onSuccess: () => {
      setSubmitted(true);
    },
    onError: (error: Error) => {
      toast({
        title: "خطا",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Flatten all questions from all sections and evaluate visibility
  const visibleQuestions = useMemo(() => {
    if (!form?.sections) return [];
    
    const allQuestions: Question[] = [];
    form.sections.forEach((section) => {
      section.questions?.forEach((question) => {
        allQuestions.push(question);
      });
    });

    const visible: Question[] = [];
    const questionMap = new Map<string, Question>();

    allQuestions.forEach((question) => {
      questionMap.set(question.id!, question);
    });

    allQuestions.forEach((question) => {
      if (!question.visibility) {
        visible.push(question);
        return;
      }

      const dependsOn = question.visibility.dependsOn;
      const showIfIn = question.visibility.showIfIn || [];

      // Find the question this depends on
      const dependsOnQuestion = Array.from(questionMap.values()).find(
        (q) => q.text === dependsOn || String(q.id) === dependsOn
      );

      if (dependsOnQuestion) {
        const answer = answers[dependsOnQuestion.id!];
        if (answer && showIfIn.includes(answer)) {
          visible.push(question);
        }
      } else {
        // If dependency not found, show by default
        visible.push(question);
      }
    });

    return visible;
  }, [form, answers]);

  const currentQuestion = visibleQuestions[currentQuestionIndex];
  const totalQuestions = visibleQuestions.length;

  const handleAnswerChange = (questionId: string, value: any, questionType?: string) => {
    setAnswers({ ...answers, [questionId]: value });
    
    // Auto-advance immediately on click for single choice questions
    if (questionType === "single_choice" && value) {
      setTimeout(() => {
        setCurrentQuestionIndex((prevIndex) => {
          if (prevIndex < visibleQuestions.length - 1) {
            return prevIndex + 1;
          }
          return prevIndex;
        });
      }, 200); // Small delay for visual feedback
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleSubmit = () => {
    if (!form) return;

    // Collect all answers
    const answerArray: Answer[] = [];
    Object.entries(answers).forEach(([questionId, value]) => {
      answerArray.push({
        question_id: String(questionId),
        value,
      });
    });

    submitMutation.mutate({
      formId: form.id!,
      answers: answerArray,
    });
  };

  const canProceed = () => {
    if (!currentQuestion) return true;
    
    if (!currentQuestion.required) return true;
    
    const answer = answers[currentQuestion.id!];
    if (currentQuestion.type === "multi_choice") {
      return Array.isArray(answer) && answer.length > 0;
    }
    return answer !== undefined && answer !== null && answer !== "";
  };

  // Update current question index when visible questions change
  useEffect(() => {
    if (visibleQuestions.length > 0 && currentQuestionIndex >= visibleQuestions.length) {
      setCurrentQuestionIndex(Math.max(0, visibleQuestions.length - 1));
    }
  }, [visibleQuestions.length, currentQuestionIndex]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-bg-secondary flex items-center justify-center">
        <div className="text-text-secondary">در حال بارگذاری...</div>
      </div>
    );
  }

  if (error || !form) {
    return (
      <div className="min-h-screen bg-bg-secondary flex items-center justify-center">
        <div className="max-w-md p-6 text-center">
          <p className="text-destructive mb-4">فرم یافت نشد</p>
          {error && (
            <p className="text-sm text-text-tertiary mb-4">
              {error.message || "خطا در بارگذاری فرم"}
            </p>
          )}
          <p className="text-xs text-text-tertiary mb-4">
            UUID: {uuid}
          </p>
          <Button onClick={() => navigate("/")}>
            بازگشت به صفحه اصلی
          </Button>
        </div>
      </div>
    );
  }

  if (showWelcome && form) {
    return <WelcomeScreen form={form} onStart={() => setShowWelcome(false)} />;
  }

  if (submitted && form) {
    return <ThankYouScreen form={form} />;
  }

  if (!currentQuestion) {
    return (
      <div className="min-h-screen bg-bg-secondary flex items-center justify-center">
        <div className="text-text-secondary">هیچ سوالی برای نمایش وجود ندارد</div>
      </div>
    );
  }

  const isLastQuestion = currentQuestionIndex === totalQuestions - 1;
  const isFirstQuestion = currentQuestionIndex === 0;

  return (
    <div className="min-h-screen bg-bg-secondary flex flex-col items-center" dir="rtl">
      <div className="w-full max-w-md">
        <div className="flex w-full h-14 items-center justify-center pt-4 pb-5">
          <h1 className="text-text-primary text-center font-bold text-base leading-5.5">
            پرسشنامه{form?.title ? ` - ${form.title}` : ''}
          </h1>
        </div>

        <div className="flex w-full px-4 flex-col items-end gap-4 pb-20">
          <div className="flex w-full p-4 flex-col items-end gap-4 rounded-xl bg-white h-[calc(100vh-168px)] overflow-hidden">
            <div className="flex flex-col items-start gap-6 w-full h-full">
              <ProgressStepper current={currentQuestionIndex + 1} total={totalQuestions} />

              <div className="text-sm font-bold text-text-secondary leading-6 text-right w-full">
                {currentQuestion.text}
              </div>

              <div className="flex flex-col items-start gap-4 w-full overflow-y-auto">
                {currentQuestion.type === "single_choice" &&
                  currentQuestion.options?.map((option, index) => (
                    <RadioButton
                      key={index}
                      id={`q${currentQuestion.id}-${index}`}
                      name={`question-${currentQuestion.id}`}
                      value={option.value}
                      label={option.text}
                      checked={answers[currentQuestion.id!] === option.value}
                      onChange={(value) => handleAnswerChange(currentQuestion.id!, value, "single_choice")}
                    />
                  ))}

                {currentQuestion.type === "multi_choice" && (
                  <>
                    {currentQuestion.options?.map((option, index) => {
                      const selectedValues = Array.isArray(answers[currentQuestion.id!]) 
                        ? answers[currentQuestion.id!] 
                        : [];
                      const isChecked = selectedValues.includes(option.value);
                      const isExclusive = currentQuestion.exclusive_options?.includes(option.value);
                      
                      return (
                        <Checkbox
                          key={index}
                          id={`q${currentQuestion.id}-${index}`}
                          name={`question-${currentQuestion.id}`}
                          value={option.value}
                          label={option.text}
                          checked={isChecked}
                          onChange={(optionValue, checked) => {
                            if (checked) {
                              if (isExclusive) {
                                handleAnswerChange(currentQuestion.id!, [optionValue]);
                              } else {
                                const filtered = selectedValues.filter(
                                  (v) => !currentQuestion.exclusive_options?.includes(v)
                                );
                                handleAnswerChange(currentQuestion.id!, [...filtered, optionValue]);
                              }
                            } else {
                              handleAnswerChange(
                                currentQuestion.id!,
                                selectedValues.filter((v) => v !== optionValue)
                              );
                            }
                          }}
                        />
                      );
                    })}
                  </>
                )}

                {currentQuestion.type === "text" && (
                  <Input
                    value={answers[currentQuestion.id!] || ""}
                    onChange={(e) => handleAnswerChange(currentQuestion.id!, e.target.value)}
                    placeholder="پاسخ خود را وارد کنید"
                    maxLength={currentQuestion.max_length}
                    minLength={currentQuestion.min_length}
                    className="w-full"
                  />
                )}

                {currentQuestion.type === "textarea" && (
                  <TextArea
                    id={`q-${currentQuestion.id}`}
                    name={`q-${currentQuestion.id}`}
                    value={answers[currentQuestion.id!] || ""}
                    onChange={(value) => handleAnswerChange(currentQuestion.id!, value)}
                    placeholder="نظرت رو برامون بنویس"
                  />
                )}

                {(currentQuestion.type === "rating" || currentQuestion.type === "scale") && (
                  <RatingInput
                    scale={currentQuestion.scale}
                    value={answers[currentQuestion.id!]}
                    onChange={(value) => handleAnswerChange(currentQuestion.id!, value)}
                    disabled={false}
                  />
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="fixed bottom-0 left-0 right-0 flex w-full max-w-md mx-auto px-4 py-3 pb-5 flex-col items-start gap-2.5 bg-bg-secondary">
          <div className="flex items-start gap-2.5 w-full">
            {!isLastQuestion ? (
              <>
                
                {!isFirstQuestion && (
                  <Button
                    onClick={handlePrevious}
                    className="flex flex-1 h-12 px-0 py-3.5 justify-center items-center gap-1 rounded-xl border border-primary bg-white text-primary font-bold text-sm leading-5 hover:bg-primary/5 transition-colors"
                  >
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 20 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M12.0253 15.6833C11.8669 15.6833 11.7086 15.625 11.5836 15.5C11.3419 15.2583 11.3419 14.8583 11.5836 14.6166L16.2003 9.99998L11.5836 5.38331C11.3419 5.14164 11.3419 4.74164 11.5836 4.49998C11.8253 4.25831 12.2253 4.25831 12.4669 4.49998L17.5253 9.55831C17.7669 9.79998 17.7669 10.2 17.5253 10.4416L12.4669 15.5C12.3419 15.625 12.1836 15.6833 12.0253 15.6833Z"
                        fill="currentColor"
                      />
                      <path
                        d="M16.942 10.625H2.91699C2.57533 10.625 2.29199 10.3417 2.29199 10C2.29199 9.65833 2.57533 9.375 2.91699 9.375H16.942C17.2837 9.375 17.567 9.65833 17.567 10C17.567 10.3417 17.2837 10.625 16.942 10.625Z"
                        fill="currentColor"
                      />
                    </svg>
                    قبلی
                  </Button>
                )}
                <Button
                  onClick={handleNext}
                  disabled={!canProceed()}
                  className={cn(
                    "flex flex-1 h-12 px-0 py-3.5 justify-center items-center gap-1 rounded-xl font-bold text-sm leading-5 transition-colors",
                    canProceed()
                      ? "bg-primary text-white hover:bg-primary/90"
                      : "bg-button-disable text-text-tertiary cursor-not-allowed"
                  )}
                >
                  بعدی
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M7.97519 15.6833C7.81686 15.6833 7.65853 15.625 7.53353 15.5L2.4752 10.4416C2.23353 10.2 2.23353 9.79998 2.4752 9.55831L7.53353 4.49998C7.7752 4.25831 8.1752 4.25831 8.41686 4.49998C8.65853 4.74164 8.65853 5.14164 8.41686 5.38331L3.8002 9.99998L8.41686 14.6166C8.65853 14.8583 8.65853 15.2583 8.41686 15.5C8.3002 15.625 8.13353 15.6833 7.97519 15.6833Z"
                      fill="currentColor"
                    />
                    <path
                      d="M17.0836 10.625H3.05859C2.71693 10.625 2.43359 10.3417 2.43359 10C2.43359 9.65833 2.71693 9.375 3.05859 9.375H17.0836C17.4253 9.375 17.7086 9.65833 17.7086 10C17.7086 10.3417 17.4253 10.625 17.0836 10.625Z"
                      fill="currentColor"
                    />
                  </svg>
                </Button>
              </>
            ) : (
              <>
                
                {!isFirstQuestion && (
                  <Button
                    onClick={handlePrevious}
                    className="flex flex-1 h-12 px-0 py-3.5 justify-center items-center gap-1 rounded-xl border border-primary bg-white text-primary font-bold text-sm leading-5 hover:bg-primary/5 transition-colors"
                  >
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 20 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M12.0253 15.6833C11.8669 15.6833 11.7086 15.625 11.5836 15.5C11.3419 15.2583 11.3419 14.8583 11.5836 14.6166L16.2003 9.99998L11.5836 5.38331C11.3419 5.14164 11.3419 4.74164 11.5836 4.49998C11.8253 4.25831 12.2253 4.25831 12.4669 4.49998L17.5253 9.55831C17.7669 9.79998 17.7669 10.2 17.5253 10.4416L12.4669 15.5C12.3419 15.625 12.1836 15.6833 12.0253 15.6833Z"
                        fill="currentColor"
                      />
                      <path
                        d="M16.942 10.625H2.91699C2.57533 10.625 2.29199 10.3417 2.29199 10C2.29199 9.65833 2.57533 9.375 2.91699 9.375H16.942C17.2837 9.375 17.567 9.65833 17.567 10C17.567 10.3417 17.2837 10.625 16.942 10.625Z"
                        fill="currentColor"
                      />
                    </svg>
                    قبلی
                  </Button>
                )}
                <Button
                  onClick={handleSubmit}
                  disabled={!canProceed() || submitMutation.isPending}
                  className={cn(
                    "flex flex-1 h-12 px-0 py-3.5 justify-center items-center gap-1 rounded-xl font-bold text-sm leading-5 transition-colors",
                    canProceed()
                      ? "bg-primary text-white hover:bg-primary/90"
                      : "bg-button-disable text-text-tertiary cursor-not-allowed"
                  )}
                >
                  {submitMutation.isPending ? "در حال ارسال..." : "ارسال"}
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M7.97519 15.6833C7.81686 15.6833 7.65853 15.625 7.53353 15.5L2.4752 10.4416C2.23353 10.2 2.23353 9.79998 2.4752 9.55831L7.53353 4.49998C7.7752 4.25831 8.1752 4.25831 8.41686 4.49998C8.65853 4.74164 8.65853 5.14164 8.41686 5.38331L3.8002 9.99998L8.41686 14.6166C8.65853 14.8583 8.65853 15.2583 8.41686 15.5C8.3002 15.625 8.13353 15.6833 7.97519 15.6833Z"
                      fill="currentColor"
                    />
                    <path
                      d="M17.0836 10.625H3.05859C2.71693 10.625 2.43359 10.3417 2.43359 10C2.43359 9.65833 2.71693 9.375 3.05859 9.375H17.0836C17.4253 9.375 17.7086 9.65833 17.7086 10C17.7086 10.3417 17.4253 10.625 17.0836 10.625Z"
                      fill="currentColor"
                    />
                  </svg>
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
