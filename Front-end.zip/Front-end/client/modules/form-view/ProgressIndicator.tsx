import { ProgressStepper } from "@/components/form/ProgressStepper";

interface ProgressIndicatorProps {
  current: number;
  total: number;
}

export function ProgressIndicator({ current, total }: ProgressIndicatorProps) {
  return <ProgressStepper current={current} total={total} />;
}

