import { Scale } from "@shared/api";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

interface ScaleInputProps {
  scale?: Scale;
  value?: number;
  onChange: (value: number) => void;
  disabled?: boolean;
}

export function ScaleInput({
  scale,
  value,
  onChange,
  disabled = false,
}: ScaleInputProps) {
  const min = scale?.min || 1;
  const max = scale?.max || 5;
  const labels = scale?.labels || [];

  return (
    <div className="flex flex-col gap-3 w-full">
      <div className="px-2">
        <Slider
          value={[value || min]}
          onValueChange={([val]) => !disabled && onChange(val)}
          min={min}
          max={max}
          step={1}
          disabled={disabled}
        />
      </div>
      <div className="flex items-center justify-between text-xs text-text-tertiary">
        <span>{min}</span>
        {value !== undefined && (
          <span className="text-text-secondary font-medium">{value}</span>
        )}
        <span>{max}</span>
      </div>
      {labels.length > 0 && value !== undefined && (
        <div className="text-center text-sm text-text-secondary">
          {labels[value - min] || ""}
        </div>
      )}
    </div>
  );
}

