import { Question } from "@shared/api";
import { RadioButton } from "@/components/form/RadioButton";
import { Checkbox } from "@/components/form/Checkbox";
import { TextArea } from "@/components/form/TextArea";
import { Input } from "@/components/ui/input";
import { RatingInput } from "./RatingInput";
import { ScaleInput } from "./ScaleInput";

interface QuestionRendererProps {
  question: Question;
  value: any;
  onChange: (value: any) => void;
  disabled?: boolean;
}

export function QuestionRenderer({
  question,
  value,
  onChange,
  disabled = false,
}: QuestionRendererProps) {
  switch (question.type) {
    case "text":
      return (
        <Input
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          placeholder="پاسخ خود را وارد کنید"
          maxLength={question.max_length}
          minLength={question.min_length}
        />
      );

    case "textarea":
      return (
        <TextArea
          id={`q-${question.id}`}
          name={`q-${question.id}`}
          value={value || ""}
          onChange={onChange}
          placeholder="پاسخ خود را وارد کنید"
        />
      );

    case "single_choice":
      return (
        <div className="flex flex-col items-start gap-4 w-full">
          {question.options?.map((option, index) => (
            <RadioButton
              key={index}
              id={`q-${question.id}-${index}`}
              name={`q-${question.id}`}
              value={option.value}
              label={option.text}
              checked={value === option.value}
              onChange={onChange}
            />
          ))}
        </div>
      );

    case "multi_choice":
      const selectedValues = Array.isArray(value) ? value : [];
      return (
        <div className="flex flex-col items-start gap-4 w-full">
          {question.options?.map((option, index) => {
            const isChecked = selectedValues.includes(option.value);
            const isExclusive =
              question.exclusive_options?.includes(option.value);
            return (
              <Checkbox
                key={index}
                id={`q-${question.id}-${index}`}
                name={`q-${question.id}`}
                value={option.value}
                label={option.text}
                checked={isChecked}
                onChange={(optionValue, checked) => {
                  if (checked) {
                    if (isExclusive) {
                      // If exclusive option selected, clear others
                      onChange([optionValue]);
                    } else {
                      // Remove any exclusive options if selecting non-exclusive
                      const filtered = selectedValues.filter(
                        (v) => !question.exclusive_options?.includes(v)
                      );
                      onChange([...filtered, optionValue]);
                    }
                  } else {
                    onChange(selectedValues.filter((v) => v !== optionValue));
                  }
                }}
              />
            );
          })}
        </div>
      );

    case "rating":
      return (
        <RatingInput
          scale={question.scale}
          value={value}
          onChange={onChange}
          disabled={disabled}
        />
      );

    case "scale":
      return (
        <ScaleInput
          scale={question.scale}
          value={value}
          onChange={onChange}
          disabled={disabled}
        />
      );

    default:
      return <div>نوع سوال پشتیبانی نمی‌شود</div>;
  }
}

