import { QuestionAnalysis as QuestionAnalysisType } from "@shared/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, LineChart, Line } from "recharts";

interface QuestionAnalysisProps {
  analysis: QuestionAnalysisType;
}

const COLORS = ['#1DBF98', '#76DFBF', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA15E', '#BC6C25'];

export function QuestionAnalysis({ analysis }: QuestionAnalysisProps) {
  const { question_text, question_type, total_answers, data } = analysis;

  if (total_answers === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{question_text}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-text-tertiary">هیچ پاسخی برای این سوال ثبت نشده است</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-lg">{question_text}</CardTitle>
        <p className="text-sm text-text-tertiary">تعداد پاسخ‌ها: {total_answers}</p>
      </CardHeader>
      <CardContent>
        {question_type === 'single_choice' && <SingleChoiceAnalysis data={data} />}
        {question_type === 'multi_choice' && <MultiChoiceAnalysis data={data} />}
        {question_type === 'rating' && <RatingAnalysis data={data} />}
        {question_type === 'scale' && <ScaleAnalysis data={data} />}
        {question_type === 'text' && <TextAnalysis data={data} short={true} />}
        {question_type === 'textarea' && <TextAnalysis data={data} short={false} />}
      </CardContent>
    </Card>
  );
}

function SingleChoiceAnalysis({ data }: { data: any }) {
  const { distribution } = data;

  const chartData = distribution.map((item: any) => ({
    name: item.label,
    value: item.count,
    percentage: item.percentage,
  }));

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold mb-4">توزیع پاسخ‌ها</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Pie Chart */}
          <ChartContainer
            config={chartData.reduce((acc: any, item: any, idx: number) => {
              acc[item.name] = { label: item.name, color: COLORS[idx % COLORS.length] };
              return acc;
            }, {})}
            className="h-[300px]"
          >
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percentage }) => `${name}: ${percentage}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {chartData.map((entry: any, index: number) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <ChartTooltip content={<ChartTooltipContent />} />
            </PieChart>
          </ChartContainer>

          {/* Bar Chart */}
          <ChartContainer
            config={chartData.reduce((acc: any, item: any, idx: number) => {
              acc[item.name] = { label: item.name, color: COLORS[idx % COLORS.length] };
              return acc;
            }, {})}
            className="h-[300px]"
          >
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="value" fill="#1DBF98" />
            </BarChart>
          </ChartContainer>
        </div>
      </div>

      {/* Summary Table */}
      <div>
        <h3 className="text-sm font-semibold mb-2">خلاصه</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-right p-2">گزینه</th>
                <th className="text-right p-2">تعداد</th>
                <th className="text-right p-2">درصد</th>
              </tr>
            </thead>
            <tbody>
              {distribution.map((item: any, idx: number) => (
                <tr key={idx} className="border-b">
                  <td className="p-2">{item.label}</td>
                  <td className="p-2">{item.count}</td>
                  <td className="p-2">{item.percentage}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function MultiChoiceAnalysis({ data }: { data: any }) {
  const { distribution, average_selections, co_occurrence_matrix } = data;

  const chartData = distribution.map((item: any) => ({
    name: item.label,
    value: item.count,
    percentage: item.percentage,
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">میانگین انتخاب‌ها</p>
            <p className="text-2xl font-bold">{average_selections}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">کل انتخاب‌ها</p>
            <p className="text-2xl font-bold">{data.total_selections}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">تعداد پاسخ‌ها</p>
            <p className="text-2xl font-bold">{data.total_responses}</p>
          </CardContent>
        </Card>
      </div>

      <div>
        <h3 className="text-sm font-semibold mb-4">فراوانی هر گزینه</h3>
        <ChartContainer
          config={chartData.reduce((acc: any, item: any, idx: number) => {
            acc[item.name] = { label: item.name, color: COLORS[idx % COLORS.length] };
            return acc;
          }, {})}
          className="h-[300px]"
        >
          <BarChart data={chartData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis type="number" />
            <YAxis dataKey="name" type="category" width={150} />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Bar dataKey="value" fill="#1DBF98" />
          </BarChart>
        </ChartContainer>
      </div>

      {/* Summary Table */}
      <div>
        <h3 className="text-sm font-semibold mb-2">خلاصه</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-right p-2">گزینه</th>
                <th className="text-right p-2">تعداد انتخاب</th>
                <th className="text-right p-2">درصد</th>
              </tr>
            </thead>
            <tbody>
              {distribution.map((item: any, idx: number) => (
                <tr key={idx} className="border-b">
                  <td className="p-2">{item.label}</td>
                  <td className="p-2">{item.count}</td>
                  <td className="p-2">{item.percentage}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function RatingAnalysis({ data }: { data: any }) {
  const { distribution, statistics } = data;

  const chartData = distribution.map((item: any) => ({
    name: item.label,
    value: item.count,
    percentage: item.percentage,
  }));

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">میانگین</p>
            <p className="text-2xl font-bold">{statistics.mean}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">میانه</p>
            <p className="text-2xl font-bold">{statistics.median}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">انحراف معیار</p>
            <p className="text-2xl font-bold">{statistics.std_dev}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">امتیاز NPS</p>
            <p className="text-2xl font-bold">{statistics.nps_score}</p>
          </CardContent>
        </Card>
      </div>

      {/* Distribution Chart */}
      <div>
        <h3 className="text-sm font-semibold mb-4">توزیع امتیازها</h3>
        <ChartContainer
          config={chartData.reduce((acc: any, item: any, idx: number) => {
            acc[item.name] = { label: item.name, color: COLORS[idx % COLORS.length] };
            return acc;
          }, {})}
          className="h-[300px]"
        >
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Bar dataKey="value" fill="#1DBF98" />
          </BarChart>
        </ChartContainer>
      </div>

      {/* NPS Breakdown */}
      <div>
        <h3 className="text-sm font-semibold mb-2">تجزیه NPS</h3>
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-text-tertiary">Promoters</p>
              <p className="text-xl font-bold text-green-600">{statistics.promoters}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-text-tertiary">Detractors</p>
              <p className="text-xl font-bold text-red-600">{statistics.detractors}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-text-tertiary">Passives</p>
              <p className="text-xl font-bold text-yellow-600">
                {data.total - statistics.promoters - statistics.detractors}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function ScaleAnalysis({ data }: { data: any }) {
  // Similar to RatingAnalysis but with diverging bar chart
  const { distribution, statistics } = data;

  const chartData = distribution.map((item: any) => ({
    name: item.label,
    value: item.count,
    percentage: item.percentage,
  }));

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">میانگین</p>
            <p className="text-2xl font-bold">{statistics.mean}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">میانه</p>
            <p className="text-2xl font-bold">{statistics.median}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">انحراف معیار</p>
            <p className="text-2xl font-bold">{statistics.std_dev}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-text-tertiary">دامنه</p>
            <p className="text-2xl font-bold">{statistics.min} - {statistics.max}</p>
          </CardContent>
        </Card>
      </div>

      {/* Distribution Chart */}
      <div>
        <h3 className="text-sm font-semibold mb-4">توزیع پاسخ‌ها</h3>
        <ChartContainer
          config={chartData.reduce((acc: any, item: any, idx: number) => {
            acc[item.name] = { label: item.name, color: COLORS[idx % COLORS.length] };
            return acc;
          }, {})}
          className="h-[300px]"
        >
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Bar dataKey="value" fill="#1DBF98" />
          </BarChart>
        </ChartContainer>
      </div>
    </div>
  );
}

function TextAnalysis({ data, short }: { data: any; short: boolean }) {
  const { frequency, word_cloud, sample_responses } = data;

  return (
    <div className="space-y-6">
      {/* Word Frequency Chart */}
      {frequency && frequency.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold mb-4">
            {short ? 'فراوانی کلمات' : 'کلمات کلیدی'}
          </h3>
          <ChartContainer
            config={frequency.slice(0, 10).reduce((acc: any, item: any, idx: number) => {
              acc[item.word] = { label: item.word, color: COLORS[idx % COLORS.length] };
              return acc;
            }, {})}
            className="h-[300px]"
          >
            <BarChart data={frequency.slice(0, 10)} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="word" type="category" width={100} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="count" fill="#1DBF98" />
            </BarChart>
          </ChartContainer>
        </div>
      )}

      {/* Word Cloud (visual representation) */}
      {word_cloud && word_cloud.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold mb-4">ابر کلمات</h3>
          <div className="flex flex-wrap gap-2 p-4 bg-bg-secondary rounded-lg">
            {word_cloud.map((item: any, idx: number) => {
              const size = Math.max(12, Math.min(24, 12 + (item.count / word_cloud[0].count) * 12));
              return (
                <span
                  key={idx}
                  className="inline-block px-2 py-1 rounded"
                  style={{
                    fontSize: `${size}px`,
                    color: COLORS[idx % COLORS.length],
                    fontWeight: item.count > word_cloud[0].count * 0.5 ? 'bold' : 'normal',
                  }}
                >
                  {item.word} ({item.count})
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Sample Responses (for long text) */}
      {!short && sample_responses && sample_responses.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold mb-4">نمونه پاسخ‌ها</h3>
          <div className="space-y-3">
            {sample_responses.map((response: string, idx: number) => (
              <Card key={idx}>
                <CardContent className="p-4">
                  <p className="text-sm">{response}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Frequency Table */}
      {frequency && frequency.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold mb-2">جدول فراوانی</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-right p-2">کلمه</th>
                  <th className="text-right p-2">تعداد</th>
                </tr>
              </thead>
              <tbody>
                {frequency.slice(0, 20).map((item: any, idx: number) => (
                  <tr key={idx} className="border-b">
                    <td className="p-2">{item.word}</td>
                    <td className="p-2">{item.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}




