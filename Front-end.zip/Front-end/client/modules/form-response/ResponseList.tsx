import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, useNavigate } from "react-router-dom";
import { getForm, getResponses, getResponse, ResponseDetail } from "@shared/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ResponseDetail as ResponseDetailComponent } from "./ResponseDetail";
import { ExportButton } from "./ExportButton";
import { FormAnalysis } from "./FormAnalysis";
import { ArrowRight } from "lucide-react";

export function ResponseList() {
  const { formId } = useParams<{ formId: string }>();
  const navigate = useNavigate();
  const [selectedResponse, setSelectedResponse] = useState<ResponseDetail | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const { data: form } = useQuery({
    queryKey: ["form", formId],
    queryFn: () => getForm(String(formId!)),
    enabled: !!formId,
  });

  // Update page title
  useEffect(() => {
    if (form?.title) {
      document.title = `پاسخ‌ها - ${form.title}`;
    } else {
      document.title = "پاسخ‌ها";
    }
    
    // Cleanup: reset title when component unmounts
    return () => {
      document.title = "سیستم فرم‌ساز";
    };
  }, [form?.title]);

  const { data: responses, isLoading } = useQuery({
    queryKey: ["responses", formId],
    queryFn: () => getResponses(String(formId!)),
    enabled: !!formId,
  });

  const filteredResponses = responses?.filter((response) => {
    if (!searchTerm) return true;
    const searchLower = searchTerm.toLowerCase();
    return (
      response.user_id?.toLowerCase().includes(searchLower) ||
      response.submitted_at.toLowerCase().includes(searchLower) ||
      String(response.id).includes(searchLower)
    );
  });

  if (isLoading) {
    return <div className="p-8">در حال بارگذاری...</div>;
  }

  if (selectedResponse) {
    return (
      <ResponseDetailComponent
        response={selectedResponse}
        form={form}
        onBack={() => setSelectedResponse(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-bg-secondary p-4" dir="rtl">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-text-primary mb-2">
              {form?.title || "پاسخ‌ها"}
            </h1>
            <p className="text-text-secondary">
              {responses?.length || 0} پاسخ ثبت شده
            </p>
          </div>
          <div className="flex gap-2">
            {responses && responses.length > 0 && (
              <ExportButton responses={responses} form={form} />
            )}
            <Button onClick={() => navigate("/responses")} variant="outline">
              بازگشت
            </Button>
          </div>
        </div>

        <Tabs defaultValue="responses" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="responses">پاسخ‌ها</TabsTrigger>
            <TabsTrigger value="analysis">تحلیل</TabsTrigger>
          </TabsList>

          <TabsContent value="responses" className="space-y-4">
            <Card className="mb-4">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Label htmlFor="search">جستجو:</Label>
                  <Input
                    id="search"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="جستجو در پاسخ‌ها..."
                    className="max-w-sm"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="space-y-3">
              {filteredResponses && filteredResponses.length > 0 ? (
                filteredResponses.map((response) => (
                  <Card
                    key={response.id}
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={async () => {
                      // Fetch full response details
                      const fullResponse = await getResponse(String(response.id));
                      setSelectedResponse(fullResponse);
                    }}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-sm font-medium text-text-primary">
                              {response.display_name || `پاسخ #${response.id}`}
                            </span>
                          </div>
                          <p className="text-xs text-text-tertiary">
                            {new Date(response.submitted_at).toLocaleString("fa-IR")}
                          </p>
                          <p className="text-sm text-text-secondary mt-2">
                            {response.answer_count} سوال پاسخ داده شده
                          </p>
                        </div>
                        <ArrowRight className="w-5 h-5 text-text-tertiary" />
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="p-8 text-center">
                    <p className="text-text-secondary">
                      {searchTerm ? "نتیجه‌ای یافت نشد" : "هیچ پاسخی ثبت نشده است"}
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="analysis">
            {formId && <FormAnalysis formId={String(formId)} />}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

