import { Form, ResponseDetail } from "@shared/api";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { getResponse } from "@shared/api";

interface ExportButtonProps {
  responses: Array<{ id: number }>;
  form: Form | undefined;
}

export function ExportButton({ responses, form }: ExportButtonProps) {
  const exportToCSV = async () => {
    if (!responses || responses.length === 0) return;

    // Fetch full response details for export
    const fullResponses: ResponseDetail[] = await Promise.all(
      responses.map((r) => getResponse(r.id))
    );

    // Collect all unique question IDs
    const questionIds = new Set<number>();
    fullResponses.forEach((response) => {
      response.answers.forEach((answer) => {
        questionIds.add(answer.question_id);
      });
    });

    // Create headers
    const headers = ["ID", "تاریخ ثبت", "شناسه کاربر", "IP"];
    const questionMap = new Map<number, string>();

    if (form?.sections) {
      form.sections.forEach((section) => {
        section.questions?.forEach((question) => {
          if (questionIds.has(question.id!)) {
            questionMap.set(question.id!, question.text);
            headers.push(question.text);
          }
        });
      });
    }

    // Create rows
    const rows = fullResponses.map((response) => {
      const row: string[] = [
        String(response.id),
        new Date(response.submitted_at).toLocaleString("fa-IR"),
        response.user_id || "",
        response.ip_address || "",
      ];

      questionIds.forEach((questionId) => {
        const answer = response.answers.find((a) => a.question_id === questionId);
        if (answer) {
          const value = Array.isArray(answer.value)
            ? answer.value.join("; ")
            : String(answer.value);
          row.push(value);
        } else {
          row.push("");
        }
      });

      return row;
    });

    // Convert to CSV
    const csvContent = [
      headers.join(","),
      ...rows.map((row) => row.map((cell) => `"${cell}"`).join(",")),
    ].join("\n");

    // Download
    const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `responses_${form?.title || "form"}_${Date.now()}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportToJSON = async () => {
    // Fetch full response details for export
    const fullResponses: ResponseDetail[] = await Promise.all(
      responses.map((r) => getResponse(r.id))
    );

    const data = {
      form: {
        id: form?.id,
        title: form?.title,
      },
      responses: fullResponses.map((response) => ({
        id: response.id,
        submitted_at: response.submitted_at,
        user_id: response.user_id,
        ip_address: response.ip_address,
        answers: response.answers,
      })),
    };

    const jsonContent = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonContent], { type: "application/json" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `responses_${form?.title || "form"}_${Date.now()}.json`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex gap-2">
      <Button onClick={exportToCSV} variant="outline" size="sm">
        <Download className="w-4 h-4 ml-2" />
        CSV
      </Button>
      <Button onClick={exportToJSON} variant="outline" size="sm">
        <Download className="w-4 h-4 ml-2" />
        JSON
      </Button>
    </div>
  );
}

