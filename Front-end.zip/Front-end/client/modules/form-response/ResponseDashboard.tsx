import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { listForms, getResponses, Form } from "@shared/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Plus, Eye, Link as LinkIcon, Copy, Check } from "lucide-react";
import { toast } from "@/hooks/use-toast";

export function ResponseDashboard() {
  const navigate = useNavigate();
  const [selectedForm, setSelectedForm] = useState<Form | null>(null);
  const [copiedFormId, setCopiedFormId] = useState<string | null>(null);

  const { data: forms, isLoading } = useQuery({
    queryKey: ["forms"],
    queryFn: listForms,
  });

  const { data: allResponses } = useQuery({
    queryKey: ["all-responses"],
    queryFn: () => getResponses(),
  });

  const getResponseCount = (formId?: string) => {
    if (!allResponses) return 0;
    if (!formId) return allResponses.length;
    return allResponses.filter((r) => String(r.form) === String(formId)).length;
  };

  const getFormLink = (form: Form) => {
    if (!form.uuid) return "";
    return `${window.location.origin}/form/${form.uuid}`;
  };

  const copyToClipboard = async (form: Form) => {
    const link = getFormLink(form);
    if (!link) {
      toast({
        title: "خطا",
        description: "لینک فرم در دسترس نیست",
        variant: "destructive",
      });
      return;
    }

    try {
      await navigator.clipboard.writeText(link);
      setCopiedFormId(form.id!);
      toast({
        title: "کپی شد",
        description: "لینک فرم در کلیپ‌بورد کپی شد",
      });
      setTimeout(() => setCopiedFormId(null), 2000);
    } catch (err) {
      toast({
        title: "خطا",
        description: "خطا در کپی کردن لینک",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return <div className="p-8">در حال بارگذاری...</div>;
  }

  return (
    <div className="min-h-screen bg-bg-secondary p-4" dir="rtl">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-text-primary">داشبورد پاسخ‌ها</h1>
          <div className="flex gap-2">
            <Button onClick={() => navigate("/builder")} variant="outline">
              <Plus className="w-4 h-4 ml-2" />
              فرم جدید
            </Button>
            <Button onClick={() => navigate("/")} variant="ghost">
              <ArrowLeft className="w-4 h-4 ml-2" />
              بازگشت
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {forms && forms.length > 0 ? (
            forms.map((form) => (
              <Card key={form.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{form.title}</CardTitle>
                    <Badge
                      variant={form.status === "published" ? "default" : "secondary"}
                    >
                      {form.status === "published" ? "منتشر شده" : "پیش‌نویس"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-text-secondary">تعداد پاسخ‌ها:</span>
                      <span className="font-bold">{getResponseCount(form.id)}</span>
                    </div>
                    {form.description && (
                      <p className="text-sm text-text-tertiary line-clamp-2">
                        {form.description}
                      </p>
                    )}
                    <div className="flex flex-col gap-2 pt-2">
                      <div className="flex gap-2">
                        <Button
                          onClick={() => navigate(`/responses/${form.id}`)}
                          variant="outline"
                          size="sm"
                          className="flex-1"
                        >
                          <Eye className="w-4 h-4 ml-2" />
                          مشاهده پاسخ‌ها
                        </Button>
                        <Button
                          onClick={() => navigate(`/builder/${form.id}`)}
                          variant="ghost"
                          size="sm"
                        >
                          ویرایش
                        </Button>
                      </div>
                      {form.status === "published" && form.uuid && (
                        <div className="flex gap-2">
                          <Button
                            onClick={() => setSelectedForm(form)}
                            variant="outline"
                            size="sm"
                            className="flex-1"
                          >
                            <LinkIcon className="w-4 h-4 ml-2" />
                            نمایش لینک
                          </Button>
                          <Button
                            onClick={() => copyToClipboard(form)}
                            variant="outline"
                            size="sm"
                            className="flex-1"
                          >
                            {copiedFormId === form.id ? (
                              <>
                                <Check className="w-4 h-4 ml-2" />
                                کپی شد
                              </>
                            ) : (
                              <>
                                <Copy className="w-4 h-4 ml-2" />
                                کپی لینک
                              </>
                            )}
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card className="col-span-full">
              <CardContent className="p-8 text-center">
                <p className="text-text-secondary mb-4">هیچ فرمی وجود ندارد</p>
                <Button onClick={() => navigate("/builder")}>
                  <Plus className="w-4 h-4 ml-2" />
                  ایجاد فرم جدید
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        <Dialog open={!!selectedForm} onOpenChange={(open) => !open && setSelectedForm(null)}>
          <DialogContent dir="rtl" className="max-w-md">
            <DialogHeader>
              <DialogTitle>لینک عمومی فرم</DialogTitle>
              <DialogDescription>
                این لینک را با دیگران به اشتراک بگذارید تا بتوانند فرم را پر کنند
              </DialogDescription>
            </DialogHeader>
            {selectedForm && (
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={getFormLink(selectedForm)}
                    readOnly
                    className="flex-1 font-mono text-sm"
                  />
                  <Button
                    onClick={() => copyToClipboard(selectedForm)}
                    variant="outline"
                    size="icon"
                  >
                    {copiedFormId === selectedForm.id ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      const link = getFormLink(selectedForm);
                      if (link) {
                        window.open(link, "_blank");
                      }
                    }}
                    variant="default"
                    className="flex-1"
                  >
                    <LinkIcon className="w-4 h-4 ml-2" />
                    باز کردن لینک
                  </Button>
                  <Button
                    onClick={() => setSelectedForm(null)}
                    variant="outline"
                    className="flex-1"
                  >
                    بستن
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

