import { Form, ResponseDetail as ResponseDetailType } from "@shared/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight } from "lucide-react";

interface ResponseDetailProps {
  response: ResponseDetailType;
  form: Form | undefined;
  onBack: () => void;
}

export function ResponseDetail({
  response,
  form,
  onBack,
}: ResponseDetailProps) {
  const getQuestion = (questionId: string) => {
    if (!form?.sections) return null;
    for (const section of form.sections || []) {
      const question = section.questions?.find((q) => String(q.id) === String(questionId));
      if (question) return question;
    }
    return null;
  };

  const getQuestionText = (questionId: string) => {
    const question = getQuestion(questionId);
    return question?.text || `سوال ${questionId}`;
  };

  const formatAnswer = (value: any, type: string, questionId: string) => {
    const question = getQuestion(questionId);
    
    // For choice-based questions, map option IDs to text
    if (type === "single_choice" || type === "multi_choice") {
      if (!question?.options) {
        return String(value);
      }
      
      if (Array.isArray(value)) {
        // Multi-choice: map each option ID to text
        const optionTexts = value.map((optionId) => {
          const option = question.options.find((opt) => opt.value === optionId);
          return option ? option.text : optionId;
        });
        return optionTexts.join(", ");
      } else {
        // Single-choice: map option ID to text
        const option = question.options.find((opt) => opt.value === value);
        return option ? option.text : String(value);
      }
    }
    
    // For rating/scale questions, show the value with label if available
    if (type === "rating" || type === "scale") {
      if (question?.scale && typeof value === "number") {
        const labels = question.scale.labels || [];
        const min = question.scale.min || 1;
        const index = value - min;
        if (labels[index]) {
          return `${value} - ${labels[index]}`;
        }
      }
      return String(value);
    }
    
    // For arrays (multi-choice already handled above)
    if (Array.isArray(value)) {
      return value.join(", ");
    }
    
    // For objects
    if (typeof value === "object" && value !== null) {
      return JSON.stringify(value);
    }
    
    // Default: return as string
    return String(value);
  };

  return (
    <div className="min-h-screen bg-bg-secondary p-4" dir="rtl">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-text-primary">
            جزئیات پاسخ #{response.id}
          </h1>
          <Button onClick={onBack} variant="outline">
            بازگشت
          </Button>
        </div>

        <Card className="mb-4">
          <CardHeader>
            <CardTitle>اطلاعات پاسخ</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-text-secondary">تاریخ ثبت:</span>
              <span className="font-medium">
                {new Date(response.submitted_at).toLocaleString("fa-IR")}
              </span>
            </div>
            {response.user_id && (
              <div className="flex items-center justify-between">
                <span className="text-text-secondary">شناسه کاربر:</span>
                <span className="font-medium">{response.user_id}</span>
              </div>
            )}
            {response.ip_address && (
              <div className="flex items-center justify-between">
                <span className="text-text-secondary">آدرس IP:</span>
                <span className="font-medium">{response.ip_address}</span>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>پاسخ‌ها</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {response.answers.map((answer, index) => (
              <div
                key={index}
                className="p-4 border rounded-lg space-y-2"
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-text-secondary">
                    {getQuestionText(answer.question_id)}
                  </h3>
                  <Badge variant="outline">{answer.question_type}</Badge>
                </div>
                <p className="text-text-primary mt-2">
                  {formatAnswer(answer.value, answer.question_type, answer.question_id)}
                </p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

