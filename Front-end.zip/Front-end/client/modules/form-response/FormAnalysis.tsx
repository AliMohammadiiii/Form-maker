import { useQuery } from "@tanstack/react-query";
import { getFormAnalysis, FormAnalysis as FormAnalysisType } from "@shared/api";
import { QuestionAnalysis } from "./QuestionAnalysis";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

interface FormAnalysisProps {
  formId: string;
}

export function FormAnalysis({ formId }: FormAnalysisProps) {
  const { data: analysis, isLoading, error } = useQuery<FormAnalysisType>({
    queryKey: ["form-analysis", formId],
    queryFn: () => getFormAnalysis(formId),
    enabled: !!formId,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
        <span className="mr-2">در حال بارگذاری تحلیل‌ها...</span>
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-destructive">خطا در بارگذاری تحلیل‌ها</p>
        </CardContent>
      </Card>
    );
  }

  if (!analysis || analysis.total_responses === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-text-secondary">
            هنوز هیچ پاسخی برای این فرم ثبت نشده است. پس از دریافت پاسخ‌ها، تحلیل‌ها در اینجا نمایش داده می‌شوند.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-text-primary mb-2">تحلیل پاسخ‌ها</h2>
        <p className="text-text-secondary">
          تعداد کل پاسخ‌ها: <span className="font-semibold">{analysis.total_responses}</span>
        </p>
      </div>

      {analysis.questions.map((questionAnalysis) => (
        <QuestionAnalysis key={questionAnalysis.question_id} analysis={questionAnalysis} />
      ))}
    </div>
  );
}

