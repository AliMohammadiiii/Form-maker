import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, LogIn, UserPlus } from "lucide-react";

export default function Index() {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();

  // Update page title
  useEffect(() => {
    document.title = "سیستم فرم‌ساز";
  }, []);

  return (
    <div className="min-h-screen bg-bg-secondary flex items-center justify-center p-4" dir="rtl">
      <div className="max-w-2xl w-full space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-text-primary mb-2">
            سیستم فرم‌ساز
          </h1>
          <p className="text-text-secondary">
            ایجاد، مدیریت و جمع‌آوری پاسخ فرم‌های پویا
          </p>
          {isAuthenticated && user && (
            <p className="text-primary mt-2">
              خوش آمدید، {user.username}
            </p>
          )}
        </div>

        {isAuthenticated ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => navigate("/dashboard")}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-primary" />
                  داشبورد
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-text-secondary">
                  مدیریت فرم‌ها و مشاهده پاسخ‌ها
                </p>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => navigate("/builder")}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-primary" />
                  ایجاد فرم جدید
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-text-secondary">
                  فرم جدیدی ایجاد کنید و سوالات خود را اضافه کنید
                </p>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => navigate("/login")}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LogIn className="w-5 h-5 text-primary" />
                  ورود
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-text-secondary">
                  برای دسترسی به داشبورد وارد شوید
                </p>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => navigate("/signup")}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-primary" />
                  ثبت نام
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-text-secondary">
                  حساب کاربری جدید ایجاد کنید
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              راهنما
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-text-secondary">
            <p>• برای استفاده از سیستم، ابتدا ثبت نام یا ورود کنید</p>
            <p>• پس از ورود، می‌توانید فرم‌های خود را ایجاد و مدیریت کنید</p>
            <p>• پس از ایجاد فرم، می‌توانید آن را منتشر کنید</p>
            <p>• لینک عمومی فرم را با دیگران به اشتراک بگذارید</p>
            <p>• پاسخ‌ها را در داشبورد خود مشاهده کنید</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
