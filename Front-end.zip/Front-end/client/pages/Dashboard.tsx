import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { listForms, deleteForm, publishForm, unpublishForm } from "@shared/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Plus, Eye, Edit, Trash2, FileText, LogOut } from "lucide-react";
import { Form } from "@shared/api";

export default function Dashboard() {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [isDeleting, setIsDeleting] = useState<number | null>(null);

  const { data: forms, isLoading, refetch } = useQuery<Form[]>({
    queryKey: ["forms"],
    queryFn: listForms,
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  // Update page title
  useEffect(() => {
    document.title = "اینجاست فرم";
    
    // Cleanup: reset title when component unmounts
    return () => {
      document.title = "سیستم فرم‌ساز";
    };
  }, []);

  const handleDelete = async (id: number) => {
    if (!confirm("آیا مطمئن هستید که می‌خواهید این فرم را حذف کنید؟")) {
      return;
    }

    setIsDeleting(id);
    try {
      await deleteForm(id);
      toast({
        title: "حذف موفق",
        description: "فرم با موفقیت حذف شد",
      });
      refetch();
    } catch (error: any) {
      toast({
        title: "خطا",
        description: error.message || "خطا در حذف فرم",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(null);
    }
  };

  const handlePublish = async (id: number, currentStatus: string) => {
    try {
      if (currentStatus === "published") {
        await unpublishForm(id);
        toast({
          title: "لغو انتشار",
          description: "فرم از حالت انتشار خارج شد",
        });
      } else {
        await publishForm(id);
        toast({
          title: "انتشار موفق",
          description: "فرم با موفقیت منتشر شد",
        });
      }
      refetch();
    } catch (error: any) {
      toast({
        title: "خطا",
        description: error.message || "خطا در تغییر وضعیت فرم",
        variant: "destructive",
      });
    }
  };

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-bg-secondary p-4" dir="rtl">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-text-primary">داشبورد</h1>
            <p className="text-text-secondary mt-1">
              خوش آمدید، {user?.username}
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => navigate("/builder")}
              className="flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              ایجاد فرم جدید
            </Button>
            <Button
              variant="outline"
              onClick={handleLogout}
              className="flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              خروج
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                تعداد فرم‌ها
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{forms?.length || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-primary" />
                فرم‌های منتشر شده
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">
                {forms?.filter((f) => f.status === "published").length || 0}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Edit className="w-5 h-5 text-primary" />
                فرم‌های پیش‌نویس
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">
                {forms?.filter((f) => f.status === "draft").length || 0}
              </p>
            </CardContent>
          </Card>
        </div>

        <div>
          <h2 className="text-2xl font-bold text-text-primary mb-4">فرم‌های من</h2>
          {isLoading ? (
            <div className="text-center py-8 text-text-secondary">در حال بارگذاری...</div>
          ) : forms && forms.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {forms.map((form) => (
                <Card key={form.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>{form.title}</CardTitle>
                    <CardDescription>
                      {form.status === "published" ? "منتشر شده" : "پیش‌نویس"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {form.uuid && form.status === "published" && (
                      <div className="text-sm text-text-secondary break-all">
                        لینک: /form/{form.uuid}
                      </div>
                    )}
                    <div className="flex gap-2 flex-wrap">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => navigate(`/builder/${form.id}`)}
                        className="flex-1"
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        ویرایش
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => navigate(`/responses/${form.id}`)}
                        className="flex-1"
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        پاسخ‌ها
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handlePublish(form.id!, form.status)}
                      >
                        {form.status === "published" ? "لغو انتشار" : "انتشار"}
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDelete(form.id!)}
                        disabled={isDeleting === form.id}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <p className="text-text-secondary mb-4">هنوز فرمی ایجاد نکرده‌اید</p>
                <Button onClick={() => navigate("/builder")}>
                  <Plus className="w-4 h-4 mr-2" />
                  ایجاد فرم جدید
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

