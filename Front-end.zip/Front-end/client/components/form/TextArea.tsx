import { cn } from "@/lib/utils";

interface TextAreaProps {
  id: string;
  name: string;
  value: string;
  placeholder: string;
  onChange: (value: string) => void;
  className?: string;
}

export function TextArea({
  id,
  name,
  value,
  placeholder,
  onChange,
  className,
}: TextAreaProps) {
  return (
    <div className="flex flex-col items-start gap-2 w-full">
      <div className="flex p-3 justify-end items-start gap-2 flex-1 self-stretch rounded-lg border border-stroke-tertiary">
        <textarea
          id={id}
          name={name}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          rows={1}
          className={cn(
            "w-full text-sm font-medium text-text-tertiary text-right leading-5",
            "bg-transparent border-none outline-none resize-none",
            "placeholder:text-text-tertiary",
            className
          )}
        />
      </div>
    </div>
  );
}
