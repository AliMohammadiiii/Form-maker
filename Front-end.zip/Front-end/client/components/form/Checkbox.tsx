import { cn } from "@/lib/utils";

interface CheckboxProps {
  id: string;
  name: string;
  value: string;
  label: string;
  checked: boolean;
  onChange: (value: string, checked: boolean) => void;
}

export function Checkbox({
  id,
  name,
  value,
  label,
  checked,
  onChange,
}: CheckboxProps) {
  return (
    <div className="flex h-6 items-start justify-end gap-4 w-full">
      {/* Control on the RIGHT, label on the LEFT (mirrored) */}
      <div className="flex items-center gap-1 order-1">
        <input
          type="checkbox"
          id={id}
          name={name}
          value={value}
          checked={checked}
          onChange={(e) => onChange(value, e.target.checked)}
          className="sr-only peer"
        />
        <label
          aria-hidden
          htmlFor={id}
          className={cn(
            "flex items-center justify-center w-6 h-6 rounded cursor-pointer border transition-all",
            checked
              ? "bg-primary border-primary"
              : "bg-white border-stroke-tertiary"
          )}
        >
          {checked && (
            <svg
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="text-white"
            >
              <path
                d="M13.3337 4L6.00033 11.3333L2.66699 8"
                stroke="currentColor"
                strokeWidth="1.6666"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          )}
        </label>
      </div>
      <label
        htmlFor={id}
        className="flex-1 order-2 text-sm font-medium text-text-secondary text-right leading-6 cursor-pointer"
      >
        {label}
      </label>
    </div>
  );
}
