import { cn } from "@/lib/utils";

interface RadioButtonProps {
  id: string;
  name: string;
  value: string;
  label: string;
  checked: boolean;
  onChange: (value: string) => void;
}

export function RadioButton({
  id,
  name,
  value,
  label,
  checked,
  onChange,
}: RadioButtonProps) {
  return (
    <div className="flex h-7 items-center justify-end gap-3 w-full">
      {/* Control on the RIGHT, label on the LEFT (mirrored) */}
      <div className="flex items-center gap-1 order-1">
        <input
          type="radio"
          id={id}
          name={name}
          value={value}
          checked={checked}
          onChange={(e) => onChange(e.target.value)}
          className="sr-only peer"
        />
        <label
          aria-hidden
          htmlFor={id}
          className={cn(
            "flex items-center justify-center w-9 h-9 p-1 cursor-pointer",
            "before:content-[''] before:block before:w-5 before:h-5 before:rounded-full",
            "before:border-[1.5px] before:transition-all",
            checked
              ? "before:border-primary before:shadow-[inset_0_0_0_4px_white,inset_0_0_0_6px_hsl(var(--primary))] before:bg-primary"
              : "before:border-stroke-tertiary before:bg-white"
          )}
        />
      </div>
      <label
        htmlFor={id}
        className="flex-1 order-2 text-sm font-medium text-text-secondary text-right leading-6 cursor-pointer"
      >
        {label}
      </label>
    </div>
  );
}
