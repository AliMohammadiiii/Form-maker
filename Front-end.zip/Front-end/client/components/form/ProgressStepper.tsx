interface ProgressStepperProps {
  current: number;
  total: number;
}

export function ProgressStepper({ current, total }: ProgressStepperProps) {
  const percentage = (current / total) * 100;

  return (
    <div className="flex items-start gap-3 w-full">
      <div className="h-6 flex-1 relative">
        <div className="absolute left-0 top-2.5 w-full h-1 rounded-xl bg-neutral-200">
          <div
            className="h-1 rounded-xl bg-primary transition-all duration-300"
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
      <div className="text-sm font-bold text-text-secondary leading-6 text-right">
        {current}/{total}
      </div>
    </div>
  );
}
