import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import React from "react";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Parses markdown-style bold text (**text**) and returns React elements
 * Also handles line breaks (\n) by converting them to <br /> elements
 * @param text - The text to parse
 * @returns Array of React elements with bold formatting and line breaks applied
 */
export function parseBoldText(text: string): (string | React.ReactElement)[] {
  const parts: (string | React.ReactElement)[] = [];
  const lines = text.split('\n');
  let key = 0;

  lines.forEach((line, lineIndex) => {
    // Parse bold text in this line
    const lineParts = parseBoldInLine(line, key);
    parts.push(...lineParts);
    
    // Update key counter based on what was added
    key += lineParts.filter(p => typeof p !== 'string').length;
    
    // Add <br /> after each line except the last one
    if (lineIndex < lines.length - 1) {
      parts.push(React.createElement('br', { key: key++ }));
    }
  });

  return parts;
}

/**
 * Parses bold text (**text**) in a single line
 * @param line - The line of text to parse
 * @param startKey - Starting key value for React elements
 * @returns Array of strings and React elements
 */
function parseBoldInLine(line: string, startKey: number): (string | React.ReactElement)[] {
  const parts: (string | React.ReactElement)[] = [];
  const regex = /\*\*(.+?)\*\*/g;
  let lastIndex = 0;
  let match;
  let key = startKey;

  while ((match = regex.exec(line)) !== null) {
    // Add text before the bold section
    if (match.index > lastIndex) {
      parts.push(line.substring(lastIndex, match.index));
    }
    
    // Add the bold text
    parts.push(
      React.createElement('strong', { key: key++, style: { fontWeight: 700 } }, match[1])
    );
    
    lastIndex = regex.lastIndex;
  }

  // Add remaining text after the last match
  if (lastIndex < line.length) {
    parts.push(line.substring(lastIndex));
  }

  // If no matches found, return the original line
  if (parts.length === 0) {
    return [line];
  }

  return parts;
}
